package org.example.accountbookserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountBookServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AccountBookServerApplication.class, args);
    }

}
