const BASE_URL = require('../../utils/config.js').BASE_URL;

Page({
  data: {
    currentTab: '支出',
    amount: '',
    currentTypeId: null,
    typeList: [
      { id: 1, name: "餐饮", icon: "🍜", color: "#07c160", category: "支出" },
      { id: 2, name: "购物", icon: "🛍️", color: "#ff976a", category: "支出" },
      { id: 3, name: "教育", icon: "🎓", color: "#1890ff", category: "支出" },
      { id: 4, name: "交通", icon: "🚇", color: "#722ed1", category: "支出" },
      { id: 5, name: "工资", icon: "💰", color: "#52c41a", category: "收入" }
    ],
    remark: '',
    canSubmit: false,
    showCustomModal: false,
    customName: '',
    customIcon: '',
    customColor: '#07c160',
    showDeleteMode: false,
    deleteConfirmId: null
  },

  onLoad() {
    this.loadCustomTypes();
  },

  // 加载自定义类型
  loadCustomTypes() {
    const customTypes = wx.getStorageSync('customTypes') || [];
    const markedCustomTypes = customTypes.map(t => ({
      ...t,
      isCustom: true
    }));
    
    this.setData({ 
      typeList: [...this.data.typeList.filter(t => !t.isCustom), ...markedCustomTypes] 
    });
  },

  // 切换支出/收入
  switchType(e) {
    this.setData({ 
      currentTab: e.currentTarget.dataset.type, 
      currentTypeId: null, 
      canSubmit: false 
    });
  },

  // ==================== 金额输入 - 关键修改 ====================
  
  inputAmount(e) {
    let value = e.detail.value;
    
    // 1. 移除非数字和小数点
    value = value.replace(/[^\d.]/g, '');
    
    // 2. 只能有一个小数点
    const parts = value.split('.');
    if (parts.length > 2) {
      value = parts[0] + '.' + parts.slice(1).join('');
    }
    
    // 3. 小数点后最多两位
    if (parts.length === 2 && parts[1].length > 2) {
      value = parts[0] + '.' + parts[1].substring(0, 2);
    }
    
    // 4. 不能以多个0开头（如 00.5 变成 0.5）
    if (value.startsWith('0') && value.length > 1 && value[1] !== '.') {
      value = value.replace(/^0+/, '0');
    }
    
    // 5. 更新显示
    this.setData({ amount: value });
    
    // 6. 检查是否可以提交（必须大于0）
    this.checkSubmit();
    
    // 返回处理后的值，确保输入框显示正确
    return value;
  },

  // 检查是否可以提交
  checkSubmit() {
    const { amount, currentTypeId } = this.data;
    const numAmount = parseFloat(amount);
    // 金额必须大于0，且选择了类型
    this.setData({ 
      canSubmit: amount && numAmount > 0 && !!currentTypeId 
    });
  },

  // 选择类型
  selectType(e) {
    this.setData({ currentTypeId: e.currentTarget.dataset.id });
    this.checkSubmit();
  },

  // 输入备注
  inputRemark(e) {
    this.setData({ remark: e.detail.value });
  },

  // ==================== 删除自定义类型 ====================

  toggleDeleteMode() {
    this.setData({ 
      showDeleteMode: !this.data.showDeleteMode,
      deleteConfirmId: null
    });
  },

  onDeleteType(e) {
    const id = e.currentTarget.dataset.id;
    const type = this.data.typeList.find(t => t.id === id);
    if (!type.isCustom) {
      wx.showToast({ title: '基础类型不能删除', icon: 'none' });
      return;
    }
    this.setData({ deleteConfirmId: id });
  },

  confirmDelete(e) {
    const id = parseInt(e.currentTarget.dataset.id);
    let customTypes = wx.getStorageSync('customTypes') || [];
    customTypes = customTypes.filter(t => t.id !== id);
    wx.setStorageSync('customTypes', customTypes);
    
    let newData = {
      deleteConfirmId: null,
      typeList: [
        ...this.data.typeList.filter(t => !t.isCustom),
        ...customTypes.map(t => ({ ...t, isCustom: true }))
      ]
    };
    
    if (this.data.currentTypeId === id) {
      newData.currentTypeId = null;
      newData.canSubmit = false;
    }
    
    this.setData(newData);
    wx.showToast({ title: '删除成功', icon: 'success' });
  },

  cancelDelete() {
    this.setData({ deleteConfirmId: null });
  },

  // ==================== 保存记录 ====================

  submitRecord() {
    if (!this.data.canSubmit) return;

    const { currentTab, amount, currentTypeId, typeList, remark } = this.data;
    const numAmount = parseFloat(amount);
    
    // 再次校验金额
    if (!numAmount || numAmount <= 0) {
      wx.showToast({ title: '请输入有效金额', icon: 'none' });
      return;
    }

    const type = typeList.find(item => item.id === currentTypeId);
    
    const newRecord = {
      userId: 'user001',
      type: currentTab === '支出' ? 1 : 2,
      amount: numAmount,
      category: type.name,
      remark: remark || '无',
      createTime: this.formatDateTime(new Date())
    };
    
    console.log("提交的数据：", newRecord);  

    let records = wx.getStorageSync('records') || [];
    records.unshift(newRecord);
    wx.setStorageSync('records', records);

    wx.showToast({ title: '记账成功', icon: 'success' });
    wx.request({
      url: BASE_URL + "/account/add",
      method: "POST",
      data: newRecord,
      header: { "Content-Type": "application/json" },
      
      success: (res) => {
        console.log("后端保存成功", res.data);
        wx.showToast({ title: '记账成功', icon: 'success' });
        setTimeout(() => {
          wx.navigateBack({ delta: 1 });
        }, 1000);
      },
      
      fail: (err) => {
        console.error("后端保存失败", err);
        wx.showToast({ title: '提交失败', icon: 'none' });
      }
    });
    setTimeout(() => wx.navigateBack(), 1500);
  },

  // ==================== 自定义弹窗 ====================

  openCustomModal() {
    this.setData({ showCustomModal: true, customName: '', customIcon: '', customColor: '#07c160' });
  },
  
  closeCustomModal() {
    this.setData({ showCustomModal: false });
  },
  
  preventClose() {
    // 空函数，catchtap 阻止事件向上传递
  },
  
  inputCustomName(e) { this.setData({ customName: e.detail.value }); },
  inputCustomIcon(e) { this.setData({ customIcon: e.detail.value }); },
  inputCustomColor(e) { this.setData({ customColor: e.currentTarget.dataset.color }); },

  saveCustomType() {
    const { customName, customIcon, customColor, currentTab } = this.data;
    if (!customName || !customIcon) {
      wx.showToast({ title: '请完善信息', icon: 'none' });
      return;
    }

    const newType = {
      id: Date.now(),
      name: customName,
      icon: customIcon,
      color: customColor,
      category: currentTab
    };

    let customTypes = wx.getStorageSync('customTypes') || [];
    customTypes.push(newType);
    wx.setStorageSync('customTypes', customTypes);

    this.loadCustomTypes();
    this.setData({ currentTypeId: newType.id, showCustomModal: false });
    this.checkSubmit();
  },

  formatDateTime(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hour = String(date.getHours()).padStart(2, '0');
    const minute = String(date.getMinutes()).padStart(2, '0');
    const second = String(date.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
  }
});