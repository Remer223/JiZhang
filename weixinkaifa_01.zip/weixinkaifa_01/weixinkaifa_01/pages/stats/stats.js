Page({
  data: {
    totalExpense: 0,
    totalIncome: 0,
    expenseTypeStats: []
  },
  onLoad() {
    this.loadStats();
  },
  onShow() {
    this.loadStats();
  },
  loadStats() {
    const records = wx.getStorageSync('records') || [];
    let totalExpense = 0;
    let totalIncome = 0;
    const typeMap = {};

    records.forEach(item => {
      if (item.type === '支出') {
        totalExpense += item.amount;
        if (typeMap[item.typeName]) {
          typeMap[item.typeName] += item.amount;
        } else {
          typeMap[item.typeName] = item.amount;
        }
      } else {
        totalIncome += item.amount;
      }
    });

    const expenseTypeStats = Object.keys(typeMap).map(type => {
      const amount = typeMap[type];
      return {
        type,
        amount,
        percent: totalExpense ? ((amount / totalExpense) * 100).toFixed(1) : 0
      };
    });

    this.setData({
      totalExpense,
      totalIncome,
      expenseTypeStats
    });
  }
});