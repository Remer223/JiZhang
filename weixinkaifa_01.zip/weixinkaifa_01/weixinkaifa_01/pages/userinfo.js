Page({
  data: {
    avatar: "../imag/default-avatar.png", 
    nickname: "",
    account: ""
  },

  onLoad() {
    let user = wx.getStorageSync('userInfo') || {};
  
    if (
      !user.avatar ||
      user.avatar === "" ||
      user.avatar.includes('/images/')   // ← 这一句是关键
    ) {
      user.avatar = null;
    }
    this.setData(user);
  },

  // 选择头像
  chooseAvatar() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'], // 建议加上来源选择
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath;
        this.setData({
          avatar: tempFilePath
        });
        this.saveUser();
      },
      fail: (err) => {
        console.log("选择图片失败", err);
      }
    });
  },

  // 输入昵称
  inputNickname(e) {
    this.setData({ nickname: e.detail.value });
    this.saveUser();
  },

  // 输入微信号
  inputAccount(e) {
    this.setData({ account: e.detail.value });
    this.saveUser();
  },

  // 保存数据
  saveUser() {
    wx.setStorageSync('userInfo', this.data);
  }
});