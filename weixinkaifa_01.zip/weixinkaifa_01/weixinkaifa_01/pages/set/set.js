Page({
  data: {
    // 用户信息
    avatar: "../imag/default-avatar.png",
    nickname: "",
    account: "",

    // 提醒功能
    remindOn: false,
    remindTime: "20:00",
  },

  onLoad() {
    this.loadUserInfo();
    this.loadRemindSetting();
  },

  // 加载用户信息
  loadUserInfo() {
    let user = wx.getStorageSync('userInfo') || {};
    this.setData({
      avatar: user.avatar || "../imag/default-avatar.png",
      nickname: user.nickname || "",
      account: user.account || ""
    });
  },

  // 进入用户信息编辑页
  goUserInfo() {
    wx.navigateTo({
      url: "/pages/userinfo/userinfo"
    });
  },

  // 加载提醒设置
  loadRemindSetting() {
    let setting = wx.getStorageSync('remindSetting');
    if (setting) {
      this.setData({
        remindOn: setting.on,
        remindTime: setting.time
      });
    }
  },

  // 开关提醒
  switchRemind(e) {
    let isOn = e.detail.value;
    this.setData({ remindOn: isOn });

    if (isOn) {
      this.openRemind();
    } else {
      this.closeRemind();
    }
  },

  // 设置提醒时间
  setTime(e) {
    this.setData({ remindTime: e.detail });
    this.saveRemind();
  },

  // 保存提醒设置
  saveRemind() {
    wx.setStorageSync('remindSetting', {
      on: this.data.remindOn,
      time: this.data.remindTime
    });
  },

  // 开启每日提醒
  openRemind() {
    this.saveRemind();
    wx.showToast({ title: '已开启每日记账提醒', icon: 'success' });
  },

  // 关闭提醒
  closeRemind() {
    this.saveRemind();
    wx.showToast({ title: '已关闭提醒', icon: 'none' });
  }
});